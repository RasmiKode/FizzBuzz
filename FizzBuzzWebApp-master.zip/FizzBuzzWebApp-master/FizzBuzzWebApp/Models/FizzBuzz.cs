﻿namespace FizzBuzzWebApp.Models
{
    public class FizzBuzz
    {
        public string Value { get; set; }
       
    }

   
}
